This folder contains stripped and pre-parsed definitions of common Google types. These files are not used by protobuf.js directly but are here so you can use or include them where required.

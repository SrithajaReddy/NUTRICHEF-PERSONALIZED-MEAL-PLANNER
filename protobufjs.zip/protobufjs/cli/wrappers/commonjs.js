"use strict";

var $protobuf = require($DEPENDENCY);

$OUTPUT;

module.exports = $root;

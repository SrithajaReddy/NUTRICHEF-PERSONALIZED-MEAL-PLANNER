# @firebase/app-compat

This is the compatibility layer for the Firebase App package, which recreates the v8 API.

**This package is not intended for direct usage, and should only be used via the officially supported [firebase](https://www.npmjs.com/package/firebase) package.**
